
package assignment3.Problem2;


public class main {
    public static void main(String[] args)
    {
        TV obj1=new TV();
        obj1.on=true;
        obj1.turnOn();
        obj1.setChannel(5);
        obj1.setVolume(10);
        obj1.channelUp();
        obj1.channelDown();
        obj1.volumeUp();
        obj1.volumeDown();
       
        
    }
    
    
}
